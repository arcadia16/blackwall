class AgentInterface:
    pass
