LOGGING_FILEPATH = "logs/"
LOGGING_TIMEFORM = '%a %d %X'
REDIS_URL = "redis://blackwall-redis"
REDIS_CHANNEL = 'blackwall-events'
