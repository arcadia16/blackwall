# Ignore for now, no building = no server testing
# def test_home_page():
#     from requests import get
#     """Test the health status"""
#     assert get('http://localhost:5000/health', timeout=15).status_code == 200
#     print("Test is successful")
