from api import create_flask_app

if __name__ == '__main__':
    create_flask_app().run(host="0.0.0.0")
